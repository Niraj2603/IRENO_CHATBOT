package com.cognizant.ireno.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * Response DTO from Flask AI Server
 * Contains the AI-generated response and metadata
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class FlaskResponse {
    
    @JsonProperty("response")
    private String response; // AI-generated response
    
    @JsonProperty("status")
    private String status; // "success", "error", etc.
    
    @JsonProperty("processing_time")
    private Double processingTime; // Time taken by AI to process
    
    @JsonProperty("api_calls_used")
    private Integer apiCallsUsed; // Number of API calls made to external services
    
    @JsonProperty("error_message")
    private String errorMessage; // Error details if any
} 