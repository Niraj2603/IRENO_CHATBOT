# Spring Boot Chat Backend

A full-featured Spring Boot backend service that provides WebSocket-based chat functionality with integration to a Flask AI server.

## 🏗️ Architecture

```
Frontend (WebSocket) ←→ Spring Boot Backend ←→ Flask AI Server
                          ↓
                     REST API Endpoints
```

### Components

- **WebSocket Server**: Handles real-time chat connections via STOMP protocol
- **REST API**: Provides testing and health check endpoints
- **Flask Integration**: Communicates with external Flask AI service
- **Error Handling**: Comprehensive error handling with graceful fallbacks

## 🚀 Quick Start

### Prerequisites

- Java 17 or higher
- Maven 3.6+
- Flask AI server running on `localhost:5000` (optional for testing)

### Running the Application

1. **Clone and navigate to the project directory**
   ```bash
   cd demo
   ```

2. **Build the project**
   ```bash
   mvn clean compile
   ```

3. **Run the application**
   ```bash
   mvn spring-boot:run
   ```

4. **Access the application**
   - WebSocket endpoint: `ws://localhost:8080/chat`
   - REST API base: `http://localhost:8080/api`

## 📡 API Endpoints

### REST Endpoints

#### Health Check
```http
GET /api/test
```
Returns basic health status and Flask server connectivity.

#### LLM Testing
```http
POST /api/llm-test
Content-Type: application/json

{
  "query": "Hello, how are you?"
}
```
Test Flask AI integration without WebSocket.

#### System Status
```http
GET /api/status
```
Detailed system status including Flask server health.

### WebSocket Endpoints

#### Chat Messages
- **Connection**: `ws://localhost:8080/chat`
- **Send to**: `/app/chat`
- **Subscribe to**: `/topic/messages`

**Message Format:**
```json
{
  "sender": "user",
  "content": "Your message here",
  "timestamp": "2024-01-01T12:00:00"
}
```

## 🔧 Configuration

### Application Properties

Key configuration options in `src/main/resources/application.properties`:

```properties
# Server Configuration
server.port=8080

# Flask Server URL
flask.server.url=http://localhost:5000

# WebSocket Configuration
spring.websocket.max-text-message-size=65536

# Logging
logging.level.com.example=DEBUG
```

### Flask Server Requirements

Your Flask server should expose:

**POST** `/llm-query`
```json
Request: {"query": "user message"}
Response: {"response": "AI response"}
```

**GET** `/health` (optional)
```json
Response: "OK" or any 200 status
```

## 🏗️ Project Structure

```
src/main/java/com/example/
├── MainApplication.java              # Spring Boot entry point
├── config/
│   └── WebSocketConfig.java         # WebSocket configuration
├── controller/
│   ├── ChatController.java          # WebSocket message handling
│   └── TestRestController.java      # REST API endpoints
├── model/
│   └── ChatMessage.java            # Message data model
├── service/
│   └── FlaskClientService.java     # Flask integration service
└── exception/
    └── GlobalExceptionHandler.java  # Error handling

src/main/resources/
└── application.properties           # Configuration

src/test/java/com/example/
└── service/
    └── FlaskClientServiceTest.java # Unit tests
```

## 🔍 WebSocket Client Example

### JavaScript/Browser
```javascript
// Connect to WebSocket
const socket = new SockJS('http://localhost:8080/chat');
const stompClient = Stomp.over(socket);

stompClient.connect({}, function(frame) {
    console.log('Connected: ' + frame);
    
    // Subscribe to messages
    stompClient.subscribe('/topic/messages', function(message) {
        const chatMessage = JSON.parse(message.body);
        console.log('Received:', chatMessage);
    });
    
    // Send a message
    stompClient.send('/app/chat', {}, JSON.stringify({
        'sender': 'user',
        'content': 'Hello AI!',
        'timestamp': new Date().toISOString()
    }));
});
```

## 🛠️ Development

### Running Tests
```bash
mvn test
```

### Building for Production
```bash
mvn clean package
java -jar target/demo-1.0-SNAPSHOT.jar
```

### Hot Reload (Development)
The application supports Spring Boot DevTools for automatic restarts during development.

## 🔒 Error Handling

The application includes comprehensive error handling:

- **Flask Server Offline**: Returns fallback message "AI service is currently offline"
- **Request Timeouts**: 30-second timeout with appropriate error messages
- **Invalid Requests**: Validation and error responses
- **WebSocket Errors**: Graceful error handling for WebSocket communications

## 📊 Monitoring

### Built-in Endpoints
- `/actuator/health` - Application health status
- `/actuator/info` - Application information

### Logging
Structured logging with different levels:
- `DEBUG`: WebSocket and Flask communication details
- `INFO`: General application flow
- `WARN`: Non-critical issues
- `ERROR`: Error conditions

## 🚀 Production Considerations

1. **Security**: Update CORS configuration for production domains
2. **Scaling**: Consider using message brokers (Redis, RabbitMQ) for multi-instance deployments
3. **SSL**: Configure HTTPS/WSS for production
4. **Monitoring**: Add APM tools (Micrometer, Prometheus)
5. **Database**: Add persistence layer if message history is required

## 🐛 Troubleshooting

### Common Issues

1. **Flask Server Connection Failed**
   - Verify Flask server is running on `localhost:5000`
   - Check Flask server has `/llm-query` endpoint
   - Review logs for connection errors

2. **WebSocket Connection Issues**
   - Ensure client is connecting to correct endpoint
   - Check browser console for SockJS/STOMP errors
   - Verify CORS configuration

3. **Build Failures**
   - Ensure Java 17 is installed
   - Clear Maven cache: `mvn clean`
   - Check internet connectivity for dependency downloads

### Logs Location
Application logs are output to console by default. For file logging, add:
```properties
logging.file.name=application.log
```

## 🤝 Contributing

1. Follow the existing code style and structure
2. Add unit tests for new functionality
3. Update documentation for API changes
4. Test with actual Flask server integration

## 📄 License

This project is part of a demo application for educational purposes. 