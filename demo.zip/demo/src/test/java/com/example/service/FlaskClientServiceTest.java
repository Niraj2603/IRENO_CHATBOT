package com.example.service;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockedStatic;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import reactor.core.publisher.Mono;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

/**
 * Unit tests for FlaskClientService
 * Tests core functionality without external dependencies
 */
class FlaskClientServiceTest {

    private FlaskClientService flaskClientService;

    @BeforeEach
    void setUp() {
        flaskClientService = new FlaskClientService("http://localhost:5000");
    }

    @Test
    void testQueryLLM_WithValidInput() {
        // Test that the service handles null input gracefully
        String result = flaskClientService.queryLLM("Hello");
        
        // The result should not be null and should contain a fallback message
        // when Flask server is not available
        assertNotNull(result);
        assertTrue(result.contains("AI") || result.contains("unavailable") || result.contains("offline"));
    }

    @Test
    void testQueryLLM_WithEmptyInput() {
        // Test empty input handling
        String result = flaskClientService.queryLLM("");
        
        assertNotNull(result);
        // Should handle empty input gracefully
    }

    @Test
    void testQueryLLM_WithNullInput() {
        // Test null input handling
        String result = flaskClientService.queryLLM(null);
        
        assertNotNull(result);
        // Should handle null input gracefully
    }

    @Test
    void testIsFlaskServerReachable_WhenServerDown() {
        // When Flask server is not running, should return false
        boolean result = flaskClientService.isFlaskServerReachable();
        
        // This will be false if Flask server is not running on localhost:5000
        // This is expected behavior for the test
        assertFalse(result);
    }

    @Test
    void testFlaskResponse_GettersAndSetters() {
        // Test the inner FlaskResponse class
        FlaskClientService.FlaskResponse response = new FlaskClientService.FlaskResponse();
        String testResponse = "Test AI response";

        response.setResponse(testResponse);
        assertEquals(testResponse, response.getResponse());
    }

    @Test
    void testFlaskResponse_DefaultConstructor() {
        // Test default constructor
        FlaskClientService.FlaskResponse response = new FlaskClientService.FlaskResponse();
        assertNull(response.getResponse());
    }

    @Test
    void testServiceInitialization() {
        // Test that service can be initialized with different URLs
        FlaskClientService customService = new FlaskClientService("http://custom-host:8080");
        
        assertNotNull(customService);
        
        // Test with null input to verify service is working
        String result = customService.queryLLM("test");
        assertNotNull(result);
    }
} 