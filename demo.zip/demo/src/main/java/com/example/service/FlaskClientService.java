package com.example.service;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientRequestException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

import java.time.Duration;
import java.util.Map;

/**
 * Service class for communicating with the Flask AI server
 * Handles HTTP requests to the LLM endpoint with proper error handling and timeouts
 */
@Service
@Slf4j
public class FlaskClientService {
    
    private final WebClient webClient;
    private final String flaskUrl;
    
    public FlaskClientService(@Value("${flask.server.url:http://localhost:5000}") String flaskUrl) {
        this.flaskUrl = flaskUrl;
        this.webClient = WebClient.builder()
                .baseUrl(flaskUrl)
                .build();
        
        log.info("FlaskClientService initialized with URL: {}", flaskUrl);
    }
    
    /**
     * Query the Flask LLM server with a user message
     * @param userQuery The user's query to send to the AI
     * @return The AI's response or a fallback message if the service is unavailable
     */
    public String queryLLM(String userQuery) {
        try {
            log.debug("Sending query to Flask server: {}", userQuery);
            
            // Create request body
            Map<String, String> requestBody = Map.of("query", userQuery);
            
            // Make async request with timeout
            String response = webClient.post()
                    .uri("/llm-query")
                    .bodyValue(requestBody)
                    .retrieve()
                    .bodyToMono(FlaskResponse.class)
                    .timeout(Duration.ofSeconds(30)) // 30 second timeout
                    .map(FlaskResponse::getResponse)
                    .onErrorResume(this::handleError)
                    .block(); // Block for synchronous operation
            
            log.debug("Received response from Flask server: {}", response);
            return response;
            
        } catch (Exception e) {
            log.error("Unexpected error while querying Flask server", e);
            return "AI is currently unavailable. Please try again later.";
        }
    }
    
    /**
     * Handle errors from Flask server communication
     */
    private Mono<String> handleError(Throwable error) {
        if (error instanceof WebClientRequestException) {
            log.error("Failed to connect to Flask server at {}: {}", flaskUrl, error.getMessage());
            return Mono.just("AI service is currently offline. Please try again later.");
        } else if (error instanceof WebClientResponseException responseEx) {
            log.error("Flask server returned error status {}: {}", 
                    responseEx.getStatusCode(), responseEx.getResponseBodyAsString());
            return Mono.just("AI service encountered an error. Please try again later.");
        } else {
            log.error("Timeout or unexpected error communicating with Flask server", error);
            return Mono.just("AI is currently unavailable. Please try again later.");
        }
    }
    
    /**
     * Test connection to Flask server
     * @return true if server is reachable, false otherwise
     */
    public boolean isFlaskServerReachable() {
        try {
            webClient.get()
                    .uri("/health")
                    .retrieve()
                    .bodyToMono(String.class)
                    .timeout(Duration.ofSeconds(5))
                    .block();
            return true;
        } catch (Exception e) {
            log.warn("Flask server health check failed: {}", e.getMessage());
            return false;
        }
    }
    
    /**
     * Inner class to map Flask server response
     */
    public static class FlaskResponse {
        private String response;
        
        public FlaskResponse() {}
        
        public String getResponse() {
            return response;
        }
        
        public void setResponse(String response) {
            this.response = response;
        }
    }
} 