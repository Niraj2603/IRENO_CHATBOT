package com.example.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.messaging.handler.annotation.MessageExceptionHandler;
import org.springframework.messaging.simp.annotation.SendToUser;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * Global exception handler for the chat backend application
 * Handles both REST and WebSocket exceptions gracefully
 */
@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * Handle general exceptions in REST controllers
     */
    @ExceptionHandler(Exception.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Map<String, Object>> handleGenericException(Exception e) {
        log.error("Unhandled exception occurred", e);
        
        Map<String, Object> errorResponse = Map.of(
                "status", "error",
                "message", "An unexpected error occurred",
                "timestamp", LocalDateTime.now(),
                "details", e.getMessage() != null ? e.getMessage() : "No details available"
        );
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }

    /**
     * Handle illegal argument exceptions
     */
    @ExceptionHandler(IllegalArgumentException.class)
    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public ResponseEntity<Map<String, Object>> handleIllegalArgumentException(IllegalArgumentException e) {
        log.warn("Invalid argument provided: {}", e.getMessage());
        
        Map<String, Object> errorResponse = Map.of(
                "status", "error",
                "message", "Invalid request parameters",
                "timestamp", LocalDateTime.now(),
                "details", e.getMessage()
        );
        
        return ResponseEntity.badRequest().body(errorResponse);
    }

    /**
     * Handle WebSocket message exceptions
     * This will send error messages back to the specific user who caused the error
     */
    @MessageExceptionHandler
    @SendToUser("/queue/errors")
    public Map<String, Object> handleWebSocketException(Exception e) {
        log.error("WebSocket message handling error", e);
        
        return Map.of(
                "type", "error",
                "message", "Failed to process your message. Please try again.",
                "timestamp", LocalDateTime.now(),
                "details", e.getMessage() != null ? e.getMessage() : "Unknown error"
        );
    }

    /**
     * Handle connection timeout exceptions
     */
    @ExceptionHandler(java.net.SocketTimeoutException.class)
    @ResponseStatus(HttpStatus.REQUEST_TIMEOUT)
    public ResponseEntity<Map<String, Object>> handleTimeoutException(java.net.SocketTimeoutException e) {
        log.warn("Request timeout: {}", e.getMessage());
        
        Map<String, Object> errorResponse = Map.of(
                "status", "timeout",
                "message", "Request timed out. Please try again.",
                "timestamp", LocalDateTime.now()
        );
        
        return ResponseEntity.status(HttpStatus.REQUEST_TIMEOUT).body(errorResponse);
    }

    /**
     * Handle null pointer exceptions
     */
    @ExceptionHandler(NullPointerException.class)
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ResponseEntity<Map<String, Object>> handleNullPointerException(NullPointerException e) {
        log.error("Null pointer exception occurred", e);
        
        Map<String, Object> errorResponse = Map.of(
                "status", "error",
                "message", "A system error occurred",
                "timestamp", LocalDateTime.now(),
                "details", "Please contact support if this issue persists"
        );
        
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }
} 