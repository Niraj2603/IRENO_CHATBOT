package com.example;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Main Spring Boot Application class for the Chat Backend
 * This application serves as a WebSocket server that connects to a Flask AI service
 */
@SpringBootApplication
public class MainApplication {

    public static void main(String[] args) {
        SpringApplication.run(MainApplication.class, args);
        System.out.println("🚀 Spring Boot Chat Backend started successfully!");
        System.out.println("📡 WebSocket endpoint available at: ws://localhost:8080/chat");
        System.out.println("🔗 REST endpoints available at: http://localhost:8080/test");
    }
} 