package com.example.controller;

import com.example.service.FlaskClientService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.Map;

/**
 * REST controller for testing backend functionality
 * Provides simple endpoints to verify the system is working
 */
@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*") // Allow all origins for development
public class TestRestController {
    
    private final FlaskClientService flaskClientService;
    
    /**
     * Simple health check endpoint
     * @return Status message indicating backend is working
     */
    @GetMapping("/test")
    public ResponseEntity<Map<String, Object>> testEndpoint() {
        log.info("Test endpoint called");
        
        Map<String, Object> response = Map.of(
                "status", "success",
                "message", "Backend is working",
                "timestamp", LocalDateTime.now(),
                "flaskServerReachable", flaskClientService.isFlaskServerReachable()
        );
        
        return ResponseEntity.ok(response);
    }
    
    /**
     * Test Flask LLM integration without WebSocket
     * @param request Request body containing the query
     * @return AI response from Flask server
     */
    @PostMapping("/llm-test")
    public ResponseEntity<Map<String, Object>> testLLM(@RequestBody Map<String, String> request) {
        String query = request.get("query");
        
        if (query == null || query.trim().isEmpty()) {
            log.warn("Received empty query in LLM test");
            return ResponseEntity.badRequest().body(Map.of(
                    "status", "error",
                    "message", "Query cannot be empty",
                    "timestamp", LocalDateTime.now()
            ));
        }
        
        log.info("Testing LLM with query: {}", query);
        
        try {
            String aiResponse = flaskClientService.queryLLM(query.trim());
            
            Map<String, Object> response = Map.of(
                    "status", "success",
                    "query", query,
                    "response", aiResponse,
                    "timestamp", LocalDateTime.now()
            );
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            log.error("Error testing LLM", e);
            
            Map<String, Object> errorResponse = Map.of(
                    "status", "error",
                    "message", "Failed to get response from AI service",
                    "error", e.getMessage(),
                    "timestamp", LocalDateTime.now()
            );
            
            return ResponseEntity.internalServerError().body(errorResponse);
        }
    }
    
    /**
     * Get system information
     * @return System status and configuration details
     */
    @GetMapping("/status")
    public ResponseEntity<Map<String, Object>> getSystemStatus() {
        log.info("System status endpoint called");
        
        Map<String, Object> status = Map.of(
                "application", "Spring Boot Chat Backend",
                "status", "running",
                "timestamp", LocalDateTime.now(),
                "flask", Map.of(
                        "reachable", flaskClientService.isFlaskServerReachable(),
                        "url", "http://localhost:5000"
                ),
                "websocket", Map.of(
                        "endpoint", "ws://localhost:8080/chat",
                        "protocols", "STOMP, SockJS"
                )
        );
        
        return ResponseEntity.ok(status);
    }
} 