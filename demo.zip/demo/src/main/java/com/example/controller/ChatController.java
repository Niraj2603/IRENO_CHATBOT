package com.example.controller;

import com.example.model.ChatMessage;
import com.example.service.FlaskClientService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.messaging.handler.annotation.MessageMapping;
import org.springframework.messaging.handler.annotation.SendTo;
import org.springframework.stereotype.Controller;

import java.time.LocalDateTime;

/**
 * WebSocket controller for handling chat messages
 * Receives messages via WebSocket, processes them through Flask AI service,
 * and broadcasts responses to all connected clients
 */
@Controller
@RequiredArgsConstructor
@Slf4j
public class ChatController {
    
    private final FlaskClientService flaskClientService;
    
    /**
     * Handle incoming chat messages from WebSocket clients
     * @param message The incoming chat message from a user
     * @return AI response message to be broadcast to all subscribers
     */
    @MessageMapping("/chat")
    @SendTo("/topic/messages")
    public ChatMessage handleChatMessage(ChatMessage message) {
        try {
            log.info("Received message from {}: {}", message.getSender(), message.getContent());
            
            // Validate incoming message
            if (message.getContent() == null || message.getContent().trim().isEmpty()) {
                log.warn("Received empty message from {}", message.getSender());
                return new ChatMessage("system", "Please send a non-empty message.", LocalDateTime.now());
            }
            
            // First, echo the user message to all clients (optional, for chat history)
            // This could be handled on the frontend instead
            
            // Query the Flask AI service
            String aiResponse = flaskClientService.queryLLM(message.getContent().trim());
            
            // Create and return AI response message
            ChatMessage aiMessage = new ChatMessage("ai", aiResponse, LocalDateTime.now());
            
            log.info("Sending AI response: {}", aiResponse);
            return aiMessage;
            
        } catch (Exception e) {
            log.error("Error processing chat message", e);
            return new ChatMessage("system", 
                    "Sorry, there was an error processing your message. Please try again.", 
                    LocalDateTime.now());
        }
    }
    
    /**
     * Handle system messages or announcements
     * @param content The system message content
     * @return System message to broadcast
     */
    @MessageMapping("/system")
    @SendTo("/topic/messages")
    public ChatMessage handleSystemMessage(String content) {
        log.info("Broadcasting system message: {}", content);
        return new ChatMessage("system", content, LocalDateTime.now());
    }
} 