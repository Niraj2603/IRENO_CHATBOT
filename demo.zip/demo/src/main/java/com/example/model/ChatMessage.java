package com.example.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

/**
 * ChatMessage model representing a chat message in the system
 * Uses Lombok to reduce boilerplate code
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class ChatMessage {
    
    /**
     * The sender of the message (e.g., "user", "ai", "system")
     */
    private String sender;
    
    /**
     * The actual content/text of the message
     */
    private String content;
    
    /**
     * Timestamp when the message was created
     */
    private LocalDateTime timestamp;
    
    /**
     * Convenience constructor that sets timestamp to now
     */
    public ChatMessage(String sender, String content) {
        this.sender = sender;
        this.content = content;
        this.timestamp = LocalDateTime.now();
    }
} 